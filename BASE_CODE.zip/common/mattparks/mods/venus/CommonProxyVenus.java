package mattparks.mods.venus;

import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.event.FMLPostInitializationEvent;
import cpw.mods.fml.common.event.FMLPreInitializationEvent;

public class CommonProxyVenus 
{
    public void registerRenderers() 
    {
    	;
    }

	public void postInit(FMLPostInitializationEvent event) 
	{
		;
	}

	public void registerRenderInformation() 
	{
		;
	}

	public void init(FMLInitializationEvent event) 
	{
		;
	}

	public void preInit(FMLPreInitializationEvent event) 
	{
		;
	}
}
